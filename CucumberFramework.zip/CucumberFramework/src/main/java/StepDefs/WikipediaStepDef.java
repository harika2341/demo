package StepDefs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Java.WikiPediaPOMPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class WikipediaStepDef {
	
	public static WebDriver driver=null;
	public static WikiPediaPOMPage wikiPediaPOMPage;
	
	
	public WikipediaStepDef()
	{
		driver=this.driver;
		wikiPediaPOMPage=PageFactory.initElements(driver, WikiPediaPOMPage.class);
	}
	
	@Given("^launch the chromebrowserand open Wikipedia website$")
	public void launch_the_chromebrowserand_open_Wikipedia_website() throws Throwable {
		wikiPediaPOMPage.launchTheBrowser();
	}

	@Then("^user verifies Wikipedia link is valid or not valid and scrape the links into excel$")
	public void user_verifies_Wikipedia_link_is_valid_or_not_valid_and_scrape_the_links_into_excel() throws Throwable {
		wikiPediaPOMPage.checkWikiPediaLinkAndScrapeIntoExcel();
	}


}
