package Java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WikiPediaPOMPage {

public static WebDriver driver;



public WikiPediaPOMPage(WebDriver driver) {
	  this.driver = driver;
	  
}

public void launchTheBrowser()
{
	String homepage = "https://www.wikipedia.org/";
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\ADMIN\\eclipse-workspace\\BDDFrameWork\\ConfigUtility\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(3000,TimeUnit.SECONDS);
	driver.get(homepage);
}

public void checkWikiPediaLinkAndScrapeIntoExcel() {
	
	
	String url = "";
	HttpURLConnection huc = null;
	int respCode = 200;

	List<WebElement> links = driver.findElements(By.tagName("a"));

	Iterator<WebElement> it = links.iterator();

	while(it.hasNext()){

	url = it.next().getAttribute("href");

	//System.out.println(url);

	if(url == null || url.isEmpty()){
	System.out.println("URL is either not configured for anchor tag or it is empty");
	continue;
	}

	try {
	huc = (HttpURLConnection)(new URL(url).openConnection());
	huc.setRequestMethod("HEAD");

	huc.connect();

	respCode = huc.getResponseCode();

	if(respCode >= 400){
	System.out.println(url+" is a broken link");
	}
	else{
	System.out.println(url+" is a valid link");
	}

	} catch (MalformedURLException e) {
	
	e.printStackTrace();
	} catch (IOException e) {
	
	e.printStackTrace();
	}
	}
}
}

	
	
	